library(shiny)
library(palmerpenguins)
library(tidyverse) 

# Define UI for application that draws a histogram
ui <- fluidPage(

    # Application title
    titlePanel("Penguins!"),
    
    #Vignette  Layouts
    navbarPage(title = "Plots",
    
        #First Vignette
        tabPanel("Histogram",
            # Sidebar with a slider input for number of bins 
            sidebarLayout(
                sidebarPanel(
                    textInput("title", "Select a Chart Title:",
                              value = "Penguin body mass",
                              ),
                    selectInput("color", "Select a Color Scheme:", 
                                choices = c("Palette 1", "Palette 2")),
                    sliderInput("bins",
                                "Number of bins:",
                                min = 1,
                                max = 50,
                                value = 30),
                    submitButton("Submit")
                ),
                # Show plot in the main panel
                mainPanel(
                   plotOutput("penguinPlot1")
                ))),
        #Second Vignette
        tabPanel("Boxplot",
                 sidebarLayout(
                     sidebarPanel(),
                     mainPanel()
                ))
))

# Define server logic required to draw a histogram
server <- function(input, output) {
    
    
    #This creates the first "output"
    output$penguinPlot1 <- renderPlot({
        
        #----------------------------------------------------------------
        # selects palette based on input$color from ui.R
        palette = case_when(
        input$color=="Palette 1"~c("darkorange","purple","cyan4"),
        input$color=="Palette 2"~c("red","blue","green"),
        TRUE~c("darkorange","purple","cyan4")
        )

        # selects variable from input$variable from ui.R
        ggplot(data=penguins,aes(x = body_mass_g)) +
            geom_histogram(aes(fill = species),
                           alpha = 0.5,
                           position = "identity",
                           # generate bins based on input$bins from ui.R
                           bins = input$bins) +
            scale_fill_manual(values = palette) +
            theme_minimal() +
            labs(x = "Body mass (g)",
                 y = "Frequency",
                 # generate a title from input$title from ui.R
                 title = input$title)
        #----------------------------------------------------------------
    })
    
    output$penguinPlot2 <- renderPlot({
        #GGPLOT HERE:-----------
        
        #-----------------------
    })
}

# Run the application 
shinyApp(ui = ui, server = server)
